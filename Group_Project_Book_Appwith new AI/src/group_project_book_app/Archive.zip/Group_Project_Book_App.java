/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package group_project_book_app;

/**
 *
 * @author victorbarnett
 */
public class Group_Project_Book_App {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BookAppFXMain.main(args);
    }
    
}
